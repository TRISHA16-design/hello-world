import streamlit as st
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import nltk
from nltk.sentiment import SentimentIntensityAnalyzer

nltk.download('vader_lexicon')

# Load Data
@st.cache_data
def load_data():
    movies = pd.read_csv("rotten_tomatoes_movies.csv")
    reviews = pd.read_csv("rotten_tomatoes_movie_reviews.csv")
    reviews['vader_sentiment'] = reviews['reviewText'].astype(str).apply(lambda x: sia.polarity_scores(x)['compound'])
    avg_sentiment = reviews.groupby('id')['vader_sentiment'].mean().reset_index()
    avg_sentiment.columns = ['id', 'avg_sentiment']
    movies = pd.merge(movies, avg_sentiment, on='id', how='left')
    movies['avg_sentiment'] = movies['avg_sentiment'].fillna(0)
    movies['combined_features'] = movies.fillna('').apply(lambda row: f"{row['genre']} {row['director']} {row['rating']}", axis=1)
    return movies

# Initialize Sentiment Analyzer
sia = SentimentIntensityAnalyzer()

# Load data
st.title("🎬 Movie Recommender System")
movies_df = load_data()

# Vectorize
tfidf = TfidfVectorizer(stop_words='english')
tfidf_matrix = tfidf.fit_transform(movies_df['combined_features'])
numeric_features = movies_df[['audienceScore', 'avg_sentiment']].fillna(0)
numeric_scaled = (numeric_features - numeric_features.min()) / (numeric_features.max() - numeric_features.min())

from scipy.sparse import hstack
final_features = hstack([tfidf_matrix, numeric_scaled])
cosine_sim = cosine_similarity(final_features, final_features)

# Index map
indices = pd.Series(movies_df.index, index=movies_df['title'].str.lower())

# Recommendation Function
def recommend(title, num_recs=5):
    title = title.lower()
    if title not in indices:
        return None
    idx = indices[title]
    sim_scores = list(enumerate(cosine_sim[idx]))
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)[1:num_recs+1]
    movie_indices = [i[0] for i in sim_scores]
    return movies_df[['title', 'genre', 'audienceScore']].iloc[movie_indices]

# UI
movie_input = st.text_input("Enter a movie title:", "The Dark Knight")
if st.button("Recommend"):
    results = recommend(movie_input)
    if results is not None:
        st.write("Top Recommendations:")
        st.dataframe(results)
    else:
        st.warning("Movie not found. Please check the title.")
